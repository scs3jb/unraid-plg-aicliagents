#!/bin/bash
# AICliAgents: Standalone Migration Test
# Non-destructive end-to-end test of legacy Btrfs → SquashFS migration.
#
# Usage:
#   ./test-migration-standalone.sh run       # Shrink fixtures, prepare, migrate, verify
#   ./test-migration-standalone.sh restore   # Return to live state
#   ./test-migration-standalone.sh status    # Show current state
#
# Flow:
#   1. Shrink fixture IMG files (if oversized) — saves Flash space and time
#   2. Backup live SquashFS state
#   3. Place legacy IMG files as if plugin was never migrated
#   4. Run the migration engine
#   5. Auto-verify: check sqsh files exist and mount correctly
#   6. Print summary — user can verify in browser at this point
#   7. Run 'restore' when done to return to normal
#
# Safety: Live files are backed up before any changes. Fixtures are copies, not originals.

set -uo pipefail

CMD="${1:-}"
ERA="${2:-img}"  # Default to Era 2 (IMG files). Use 'raw' for Era 1 (raw folders).

NAME="unraid-aicliagents"
CONFIG_DIR="/boot/config/plugins/$NAME"
PERSIST_DIR="$CONFIG_DIR/persistence"
FIXTURE_DIR="$CONFIG_DIR/test-fixtures"
BACKUP_DIR="$CONFIG_DIR/migration_testing"
EMHTTP_DEST="/usr/local/emhttp/plugins/$NAME"
HARNESS="$EMHTTP_DEST/src/scripts/dev/test-harness.sh"
SHRINK="$EMHTTP_DEST/src/scripts/dev/shrink-btrfs-image.sh"
MIGRATE="$EMHTTP_DEST/src/scripts/installer/migrate-btrfs-to-squashfs.sh"
MOUNT_STACK="$EMHTTP_DEST/src/scripts/storage/mount_stack.sh"

PASS=0
FAIL=0
WARN=0

log()   { echo -e "\033[1;34m[TEST]\033[0m $1"; }
ok()    { echo -e "\033[1;32m[PASS]\033[0m $1"; PASS=$((PASS + 1)); }
fail()  { echo -e "\033[1;31m[FAIL]\033[0m $1"; FAIL=$((FAIL + 1)); }
warn()  { echo -e "\033[1;33m[WARN]\033[0m $1"; WARN=$((WARN + 1)); }
sep()   { echo "────────────────────────────────────────────────"; }

# ═══════════════════════════════════════════
# Phase 1: Shrink Fixtures
# ═══════════════════════════════════════════
shrink_fixtures() {
    log "Phase 1: Shrinking fixture IMG files..."
    sep

    if [ ! -f "$SHRINK" ]; then
        warn "Shrink script not found at $SHRINK — skipping"
        return
    fi

    for img in "$FIXTURE_DIR"/*.img.migrated; do
        [ ! -f "$img" ] && continue
        local name=$(basename "$img")
        local size_mb=$(( $(stat -c%s "$img" 2>/dev/null || echo 0) / 1024 / 1024 ))

        # Skip if already small (under 500MB — already shrunk)
        if [ "$size_mb" -lt 500 ]; then
            ok "$name already compact (${size_mb} MB)"
            continue
        fi

        log "Shrinking $name (${size_mb} MB)..."
        if bash "$SHRINK" -y "$img"; then
            local new_size_mb=$(( $(stat -c%s "$img") / 1024 / 1024 ))
            ok "$name shrunk: ${size_mb} MB → ${new_size_mb} MB"
        else
            warn "$name shrink failed (non-critical, migration will still work)"
        fi
    done
    echo ""
}

# ═══════════════════════════════════════════
# Phase 2: Prepare (Backup + Place Fixtures)
# ═══════════════════════════════════════════
prepare() {
    local era="$1"
    log "Phase 2: Preparing Era ${era} state..."
    sep

    if [ ! -d "$FIXTURE_DIR" ]; then
        fail "Fixture directory not found: $FIXTURE_DIR"
        exit 1
    fi

    # Delegate to existing test harness
    if [ "$era" = "raw" ]; then
        bash "$HARNESS" prepare-raw
    else
        bash "$HARNESS" prepare-img
    fi
    echo ""
}

# ═══════════════════════════════════════════
# Phase 3: Run Migration
# ═══════════════════════════════════════════
run_migration() {
    log "Phase 3: Running migration engine..."
    sep

    if [ ! -f "$MIGRATE" ]; then
        fail "Migration script not found: $MIGRATE"
        return
    fi

    mkdir -p /tmp/unraid-aicliagents
    # Clear old migration log
    > /tmp/unraid-aicliagents/migration.log

    bash "$MIGRATE" 2>&1 | tee -a /tmp/unraid-aicliagents/migration.log
    echo ""
}

# ═══════════════════════════════════════════
# Phase 4: Auto-Verify
# ═══════════════════════════════════════════
verify() {
    log "Phase 4: Verifying migration results..."
    sep

    # Check 1: SquashFS files were created
    local agent_sqsh=$(find "$PERSIST_DIR" "$CONFIG_DIR" -maxdepth 1 -name "agent_*.sqsh" 2>/dev/null | wc -l)
    local home_sqsh=$(find "$PERSIST_DIR" "$CONFIG_DIR" -maxdepth 1 -name "home_*.sqsh" 2>/dev/null | wc -l)

    if [ "$agent_sqsh" -gt 0 ]; then
        ok "Agent SquashFS files created: $agent_sqsh"
    else
        fail "No agent SquashFS files found after migration"
    fi

    if [ "$home_sqsh" -gt 0 ]; then
        ok "Home SquashFS files created: $home_sqsh"
    else
        fail "No home SquashFS files found after migration"
    fi

    # Check 2: Legacy files moved to migrated_legacy_data (IMG era only)
    if [ -d "$PERSIST_DIR/migrated_legacy_data" ] || [ -d "$CONFIG_DIR/migrated_legacy_data" ]; then
        ok "Legacy files preserved in migrated_legacy_data/"
    elif ls "$CONFIG_DIR"/*.img "$PERSIST_DIR"/*.img 2>/dev/null | head -1 > /dev/null 2>&1; then
        warn "Legacy .img files still present (expected to be moved)"
    else
        ok "No legacy .img files remaining (raw folder migration or already cleaned)"
    fi

    # Check 3: SquashFS files are mountable
    local mount_pass=0
    local mount_fail=0
    local test_mnt="/tmp/unraid-aicliagents/verify_mnt"
    mkdir -p "$test_mnt"

    for sqsh in "$PERSIST_DIR"/agent_*_vol1.sqsh "$CONFIG_DIR"/agent_*_vol1.sqsh; do
        [ ! -f "$sqsh" ] && continue
        local name=$(basename "$sqsh")
        if mount -o loop,ro "$sqsh" "$test_mnt" 2>/dev/null; then
            # Check it has actual content
            local file_count=$(find "$test_mnt" -type f 2>/dev/null | head -5 | wc -l)
            umount -l "$test_mnt" 2>/dev/null
            if [ "$file_count" -gt 0 ]; then
                ok "  $name: mountable, has content ($file_count+ files)"
                mount_pass=$((mount_pass + 1))
            else
                fail "  $name: mountable but EMPTY"
                mount_fail=$((mount_fail + 1))
            fi
        else
            fail "  $name: FAILED to mount"
            mount_fail=$((mount_fail + 1))
        fi
    done

    for sqsh in "$PERSIST_DIR"/home_*_vol1.sqsh "$CONFIG_DIR"/home_*_vol1.sqsh; do
        [ ! -f "$sqsh" ] && continue
        local name=$(basename "$sqsh")
        if mount -o loop,ro "$sqsh" "$test_mnt" 2>/dev/null; then
            local file_count=$(find "$test_mnt" -type f 2>/dev/null | head -5 | wc -l)
            umount -l "$test_mnt" 2>/dev/null
            if [ "$file_count" -gt 0 ]; then
                ok "  $name: mountable, has content ($file_count+ files)"
                mount_pass=$((mount_pass + 1))
            else
                fail "  $name: mountable but EMPTY"
                mount_fail=$((mount_fail + 1))
            fi
        else
            fail "  $name: FAILED to mount"
            mount_fail=$((mount_fail + 1))
        fi
    done

    rmdir "$test_mnt" 2>/dev/null

    if [ "$mount_fail" -eq 0 ] && [ "$mount_pass" -gt 0 ]; then
        ok "All $mount_pass SquashFS volume(s) verified"
    elif [ "$mount_fail" -gt 0 ]; then
        fail "$mount_fail volume(s) failed verification"
    fi

    # Check 4: No migration lock left behind
    if [ -f /tmp/unraid-aicliagents/migration.lock ]; then
        fail "Stale migration.lock found"
    else
        ok "No stale migration lock"
    fi

    # Check 5: Migration log has no errors
    if [ -f /tmp/unraid-aicliagents/migration.log ]; then
        local errors=$(grep -ci "error\|fail\|fatal" /tmp/unraid-aicliagents/migration.log 2>/dev/null || echo 0)
        if [ "$errors" -gt 0 ]; then
            warn "Migration log contains $errors error/fail line(s) — review manually"
        else
            ok "Migration log clean (no error/fail lines)"
        fi
    fi

    # Check 6: File sizes are reasonable (not 0 bytes)
    local zero_files=0
    for sqsh in "$PERSIST_DIR"/*.sqsh "$CONFIG_DIR"/*.sqsh; do
        [ ! -f "$sqsh" ] && continue
        local fsize=$(stat -c%s "$sqsh" 2>/dev/null || echo 0)
        if [ "$fsize" -lt 4096 ]; then
            fail "  $(basename "$sqsh") is suspiciously small: $fsize bytes"
            zero_files=$((zero_files + 1))
        fi
    done
    [ "$zero_files" -eq 0 ] && ok "All SquashFS files have reasonable size"

    echo ""
}

# ═══════════════════════════════════════════
# Summary
# ═══════════════════════════════════════════
summary() {
    sep
    echo ""
    if [ "$FAIL" -eq 0 ]; then
        echo -e "\033[1;32m  ✓ ALL TESTS PASSED ($PASS passed, $WARN warnings)\033[0m"
    else
        echo -e "\033[1;31m  ✗ $FAIL TEST(S) FAILED ($PASS passed, $WARN warnings)\033[0m"
    fi
    echo ""
    log "Migration log: /tmp/unraid-aicliagents/migration.log"
    echo ""
    log "You can now verify in the browser:"
    log "  Settings → AI CLI Agents → Storage tab"
    log "  Settings → AI CLI Agents → Agent Store tab"
    log "  AI CLI Agents terminal → start a session"
    echo ""
    log "When done, run:  $0 restore"
    echo ""
}

# ═══════════════════════════════════════════
# Main
# ═══════════════════════════════════════════
case "$CMD" in
    "run")
        echo ""
        echo "╔══════════════════════════════════════════════════╗"
        echo "║  AICliAgents: Standalone Migration Test          ║"
        echo "║  Era: $([ "$ERA" = "raw" ] && echo "1 (Raw Folders)" || echo "2 (Btrfs IMG Files)")                            ║"
        echo "╚══════════════════════════════════════════════════╝"
        echo ""

        shrink_fixtures
        prepare "$ERA"
        run_migration
        verify
        summary
        ;;

    "restore")
        echo ""
        log "Restoring live state..."
        bash "$HARNESS" restore
        echo ""
        ok "Live state restored. Verify terminal sessions work."
        ;;

    "status")
        bash "$HARNESS" status
        ;;

    *)
        echo ""
        echo "AICliAgents Standalone Migration Test"
        echo "====================================="
        echo ""
        echo "Usage: $0 {run|restore|status} [era]"
        echo ""
        echo "  run [img|raw]  Shrink fixtures, prepare legacy state, migrate, verify"
        echo "                 img = Era 2 Btrfs images (default)"
        echo "                 raw = Era 1 raw folders"
        echo "  restore        Return to live SquashFS state"
        echo "  status         Show current test state"
        echo ""
        echo "Example:"
        echo "  $0 run img     # Test Btrfs IMG → SquashFS migration"
        echo "  $0 run raw     # Test raw folder → SquashFS migration"
        echo "  # verify in browser..."
        echo "  $0 restore     # Return to normal"
        echo ""
        exit 1
        ;;
esac
