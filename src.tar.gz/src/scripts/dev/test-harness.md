# AICliAgents: Storage Test Harness

Non-destructive testing of the Btrfs-to-SquashFS migration engine. Safely backs up your live storage before testing, restores it afterward.

## Prerequisites

- Gold Master fixture files in `/boot/config/plugins/unraid-aicliagents/test-fixtures/`:
  - `aicli-agents.img.migrated` — Legacy agent binary Btrfs image
  - `home_root.img.migrated` — Legacy user home Btrfs image (one per user)
- Run as root on the Unraid server

## Commands

```bash
cd /usr/local/emhttp/plugins/unraid-aicliagents/src/scripts/dev
```

### `prepare-img` — Set Up Era 2 (Monolithic Btrfs Images)

Safely prepares the environment for migration testing from the `.img` era.

```bash
./test-harness.sh prepare-img
```

**What it does:**
1. Persists any dirty ZRAM data and consolidates all live SquashFS layers
2. Unmounts all active overlays and ZRAM
3. Moves live `.sqsh`/`.img` files to `migration_testing/` backup directory
4. Copies fixture `aicli-agents.img.migrated` → `aicli-agents.img`
5. Copies fixture `home_*.img.migrated` → `persistence/home_*.img`

**After running:** `./test-harness.sh migrate`

### `prepare-raw` — Set Up Era 1 (Legacy Raw Folders)

Safely prepares the environment for migration testing from the oldest raw-folder era.

```bash
./test-harness.sh prepare-raw
```

**What it does:**
1. Persists any dirty ZRAM data and consolidates all live SquashFS layers
2. Unmounts all active overlays and ZRAM
3. Moves live `.sqsh`/`.img` files to `migration_testing/` backup directory
4. Mounts fixture images read-only and copies raw folder contents:
   - Agent binaries → `agents/` directory
   - Home data → `persistence/{username}/`

**After running:** `./test-harness.sh migrate`

### `migrate` — Run the Migration Engine

Runs the Btrfs-to-SquashFS migration script exactly as the PLG installer does during Phase 6.

```bash
./test-harness.sh migrate
```

**What it does:**
1. Runs `migrate-btrfs-to-squashfs.sh` in foreground with live output
2. Logs to `/tmp/unraid-aicliagents/migration.log`
3. Displays a results summary showing:
   - New SquashFS volumes created (with sizes)
   - Legacy artifacts renamed/moved by migration

**During migration:** Open the Manager page to see the migration overlay with progress bar. If Nchan is active, progress updates stream in real-time.

**After migration:** Verify in browser (Manager → Storage tab), then run `./test-harness.sh restore`.

### `restore` — Clean Up and Restore Live State

Removes all test-created artifacts and restores your original storage.

```bash
./test-harness.sh restore
```

**What it does:**
1. Unmounts any mounts from the test run
2. Removes all test-created files (`.sqsh`, `.img`, `migrated_legacy_data/`)
3. Moves backed-up files from `migration_testing/` back to their original locations
4. Reinitializes ZRAM and remounts all SquashFS stacks
5. Deletes the `migration_testing/` backup directory

**After restoring:** Agent sessions may need to be restarted from the Terminal page.

### `status` — Show Current State

Displays file inventory and whether a test is in progress.

```bash
./test-harness.sh status
```

Shows: backup state, live storage files, and available fixture files.

## Non-Destructive Test Flow

```bash
# 1. Set up legacy state (safely backs up live data first)
./test-harness.sh prepare-img

# 2. Run migration
./test-harness.sh migrate

# 3. Verify in browser
#    - Manager page: migration overlay should appear during step 2
#    - Storage tab: new SquashFS volumes + cleanup card for artifacts
#    - Terminal: sessions not available (live state is backed up)

# 4. Restore live state
./test-harness.sh restore

# 5. Verify recovery
#    - Storage tab: original SquashFS volumes back in place
#    - Terminal: restart sessions as needed
```

## Testing Both Eras

```bash
# Test Era 2 (Btrfs images)
./test-harness.sh prepare-img
./test-harness.sh migrate
./test-harness.sh restore

# Test Era 1 (raw folders)
./test-harness.sh prepare-raw
./test-harness.sh migrate
./test-harness.sh restore
```

## Watching Migration Logs

```bash
# Live log during migration
tail -f /tmp/unraid-aicliagents/migration.log

# Debug log (includes all plugin activity)
tail -f /tmp/unraid-aicliagents/debug.log
```

## Safety Guarantees

- **No data loss**: Live `.sqsh` files are moved (not deleted) to `migration_testing/`
- **Dirty data saved**: ZRAM upper layers are persisted and consolidated before backup
- **Idempotent restore**: `restore` only removes files that weren't in the backup
- **Guard against double-run**: `prepare-*` refuses to run if a backup already exists
- **Status check**: `status` shows whether a test is active and what's backed up

## Creating New Fixtures

To create fixture files from a working legacy installation:

```bash
mkdir -p /boot/config/plugins/unraid-aicliagents/test-fixtures

# Back up current agent image as fixture
cp /boot/config/plugins/unraid-aicliagents/aicli-agents.img \
   /boot/config/plugins/unraid-aicliagents/test-fixtures/aicli-agents.img.migrated

# Back up current home image as fixture
cp /boot/config/plugins/unraid-aicliagents/persistence/home_root.img \
   /boot/config/plugins/unraid-aicliagents/test-fixtures/home_root.img.migrated
```
